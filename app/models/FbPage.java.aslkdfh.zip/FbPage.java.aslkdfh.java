/**
 * 
 */
package models;

import javax.persistence.Entity;
import javax.persistence.Id;

import play.db.ebean.Model;
import com.restfb.*;
import com.restfb.types.*;

/**
 * @author Omar Elabed
 * 
 * This app is just to play a bit around with facebook requests.
 *
 */
@Entity
public class FbPage extends Model {

	private static final long serialVersionUID = 1L;

	@Id
	public long id;
	public String idString;

	private String MY_ACCESS_TOKEN="AAACEdEose0cBAF6T4DvZACMZAwdqwtVYdZBGa5UGoo5hbEOi4x6n72g2M77zFZBsZBMlj91g6oho0Hus0q3z4zZCFaizIFEr1qtpqqg2yH3I2DA3vssLhL";
	FacebookClient facebookClient = new DefaultFacebookClient(MY_ACCESS_TOKEN);

	private String[] pagenames = {
			"vivacafe.lugano",
			"52722248335",
			"115823771813441",
			"lugano.bynight",
			"estivaljazz",
			"estivalugano",
			"classcafelugano",
			"arteurbanalugano",
			"122909424460471",
			"foce.lugano",
			"milklugano",
			"usiuniversity",
			"aiesec.lugano"
	};
	private Page[] pages = new Page[pagenames.length];

	public FbPages(){
		for (int i = 0; i < pages.length; i++) {
			pages[i] = facebookClient.fetchObject(this.pagenames[i], Page.class);
		}
	}

	public Page[] getPages() {
		return pages;
	}
	
	public Page getPage(int i){
		return this.pages[i];
	}
	
	public Event[] getEvents(){
		Event[] events = new Event[pagenames.length];
		for (int i = 0; i < events.length; i++) {
			
		}
		return events;
	}
}